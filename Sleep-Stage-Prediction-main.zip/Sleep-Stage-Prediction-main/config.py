DATA_DIR = 'motion-and-heart-rate-from-a-wrist-worn-wearable-and-labeled-sleep-from-polysomnography-1.0.0'
MODEL_PATH = 'models/'
